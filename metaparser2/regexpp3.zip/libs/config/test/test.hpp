
#ifndef BOOST_CONFIG_TEST_HPP
#define BOOST_CONFIG_TEST_HPP
 
namespace empty_boost{

int test()
{
   return 0;
}

}

#endif
